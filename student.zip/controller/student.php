<?php

class studentController
{
    public function __construct()
    {
        include_once 'model/student.php';
        $this->obj = new studentModel();
    }

    public function dashbord()
    {
        include 'view/static.php';
        include 'view/dashbord.php';

    }
    public function saveData()
    {
        if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email format";
        } else {
            if (strlen($_POST['pnumber']) >= 10) {
                $a = $this->obj->saveStudData($_POST['name'], $_POST['fname'], $_POST['dob'], $_POST['address'], $_POST['city'], $_POST['state'], $_POST['pin'], $_POST['pnumber'], $_POST['email'], $_POST['class'], $_POST['marks'], date('m-d-Y'));
                echo $a;
            } else {
                echo "Please Enter valid number, phone number should be 10 digit";
            }
        }

    }
    public function edit()
    {
        include 'view/static.php';
        include 'view/edit.php';
    }

    public function updateData()
    {
        $a = $this->obj->updateStudData($_POST['name'], $_POST['fname'], $_POST['dob'], $_POST['address'], $_POST['city'], $_POST['state'], $_POST['pin'], $_POST['pnumber'], $_POST['email'], $_POST['class'], $_POST['marks'], $_POST['id']);
        echo $a;
    }

}
