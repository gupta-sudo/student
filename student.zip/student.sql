-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2021 at 01:21 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mypro`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pin` varchar(255) NOT NULL,
  `pnumber` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `marks` varchar(255) NOT NULL,
  `denroll` timestamp NOT NULL DEFAULT current_timestamp(),
  `add_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `fname`, `dob`, `address`, `city`, `state`, `pin`, `pnumber`, `email`, `class`, `marks`, `denroll`, `add_on`) VALUES
(1, 'Amit Kumar Gupta', 'Ram', '1995-01-11', 'KIrti Nagar', 'New Delhi', 'Delhi', '110015', '9999505469', 'Amit@gmail.com', 'A level', '60%', '2021-04-13 11:14:00', '2021-04-13 11:14:00'),
(2, 'Arjun Kumar Gupta', 'Ram', '1995-12-10', 'Moti Nagar', 'New Delhi', 'Delhi', '110015', '8877987652', 'Arjun@gmail.com', 'A level', '60%', '2021-04-13 11:15:19', '2021-04-13 11:15:19'),
(3, 'Kirti Kumari', 'Ram', '1995-12-10', 'Moti Nagar', 'New Delhi', 'Delhi', '110015', '9995054697', 'Kirti@gmail.com', 'A level', '60%', '2021-04-13 11:17:20', '2021-04-13 11:17:20'),
(4, 'Amit k', 'Ram', '2021-04-12', '51454545', 'New Delhi', 'Delhi', '112345', '9999999564', 'demo@gmail.com', 'B', '70%', '2021-04-13 11:18:51', '2021-04-13 11:18:51'),
(5, 'Amit k', 'Ram', '2021-04-12', '51454545', 'New Delhi', 'Delhi', '112345', '99999995645', 'demo@gmail.comm', 'B', '70%', '2021-04-13 11:18:51', '2021-04-13 11:18:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pnumber` (`pnumber`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
