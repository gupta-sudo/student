<?php
class studentModel
{
    private $dsn = "mysql:host=localhost;dbname=mypro";
    private $username = "root";
    private $password = "";
    public $pdo;
    public function __construct()
    {
        try {
            $this->pdo = new PDO($this->dsn, $this->username, $this->password);
        } catch (PDOException $e) {
            echo " " . $e->getMessage();
        }
    }

    public function saveStudData($name, $fname, $dob, $address, $city, $state, $pin, $pnumber, $email, $class, $marks, $denroll)
    {
        $sql = "SELECT count(*) FROM `student` WHERE pnumber = ? OR email=? ";
        $result = $this->pdo->prepare($sql);
        $result->execute([$pnumber, $email]);
        $number_of_rows = $result->fetchColumn();
        
        if($number_of_rows == 0){
            $sql = "INSERT INTO student(name, fname, dob, address, city, state,  pin, pnumber, email, class, marks, denroll) VALUES  (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $this->pdo->prepare($sql)->execute([$name, $fname, $dob, $address, $city, $state, $pin, $pnumber, $email, $class, $marks, $denroll]);
            echo 'Saved';
        }else{
            echo 'This record already exists.';
        }

        
        
    }

    public function showallData()
    {
        $stmt = $this->pdo->prepare("SELECT * FROM student LIMIT 100");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function viewUser($id)
    {
        $data = array();
        $sql = "SELECT * FROM student WHERE id= $id LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($result as $row) {
            $data[] = $row;
        }
        return $data;
    }

    public function updateStudData($name, $fname, $dob, $address, $city, $state, $pin, $pnumber, $email, $class, $marks, $id)
    {
        $sql = "UPDATE student SET name=?, fname=?, dob=?, address=?, city=?, state=?,  pin=?, pnumber=?, email=?, class=?, marks=? WHERE id=?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$name, $fname, $dob, $address, $city, $state, $pin, $pnumber, $email, $class, $marks, $id]);
        return "Student data Update Successfully";

    }

}
